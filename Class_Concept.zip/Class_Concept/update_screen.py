from tkinter import *
from database import database
from tkinter import messagebox



class update():
    def __init__(self):
        self.update = Tk()
        self.update.title("User Settings")
        self.update.resizable(width = False,height = True)
        self.update_width = self.update.winfo_screenwidth()
        self.updat_height = self.update.winfo_screenheight()
        self.update.config(bg = "midnightblue")
        self.update.geometry(
            "%dx%d+%d+%d" % (self.update_width / 2 - 100, self.updat_height / 2 - 100, self.update_width / 2 - (self.update_width / 2) / 2,
                             (self.updat_height / 2 - (self.updat_height / 2) / 2)))
        self.title = Label(self.update, text="User Settings", bg="midnightblue", fg="White",
                            font=("Times", "24", "bold italic"))
        self.title.place(x=0, y=0, width=(self.update_width / 2 - 100))

        label_1 = Label(self.update, text="Username", bg="midnightblue", fg="White",
                            font=("Times", "15", "bold italic"))
        label_1.place(x = 50, y= 50)
        self.usertxt_variable = StringVar()
        self.usetxt = Entry(self.update, fg="black",textvariable = self.usertxt_variable,
                            font=("Times", "18", "bold italic"))
        self.usetxt.place(x = 25 , y = 80,width = 200 , height = 40)
        label_2 = Label(self.update, text="Password", bg="midnightblue", fg="White",
                            font=("Times", "15", "bold italic"))
        label_2.place(x = 50, y= 130)
        self.pwtxt_variable = StringVar()
        self.pwtxt = Entry(self.update, fg="black",textvariable = self.pwtxt_variable,
                            font=("Times", "18", "bold italic"))
        self.pwtxt.place(x = 25 , y = 160,width = 200 , height = 40)
        label_3 = Label(self.update, text="User List", bg="midnightblue", fg="White",
                        font=("Times", "15", "bold italic"))
        label_3.place(x=400, y=50)
        scroll = Scrollbar(self.update)
        # scroll.place(x = 350,y = 310,height = 120)
        self.list_variable = StringVar()
        self.list = Listbox(self.update,listvariable = self.list_variable,font=("Times", "12", "bold italic"),
                            selectmode = SINGLE)
        self.list.place(x = 350,y = 80,width = 200,height = 120)
        self.list.config(yscrollcommand= scroll.set)
        scroll.config(command = self.list.yview)
        self.list_value()
        self.list.bind('<<ListboxSelect>>', self.getelement)
        self.add_user = Button(self.update,font = ("Times", "15", "bold italic"),text = "Add",command = lambda:self.add_entry())
        self.add_user.place(x = 270,y = 230, width = 120,height = 40)
        self.update_user_btn = Button(self.update,font = ("Times", "15", "bold italic"),text = "Update",command = lambda:self.update_entry())
        self.update_user_btn.place(x = 390,y = 230,width = 120,height = 40)




        self.update.mainloop()

    def list_value(self):
        d = database()
        value = d.show_user()
        for i in range(len(value)):
            self.list.insert(i,value[i])

    def getelement(self,event):
        try:
            selection = self.list.curselection()
            index = selection[0]
            value = self.list.get(index)
            user_pw = database()
            user_pw_value = user_pw.show_user_pw(value)
            self.usetxt.delete(0,END)
            self.usetxt.insert(0,user_pw_value[0][1])
            self.pwtxt.delete(0,END)
            self.pwtxt.insert(0,user_pw_value[0][2])
        except:
            pass

    def update_entry(self):
        data = database()
        data.update_user(self.usetxt.get(),self.usetxt.get(),self.pwtxt.get())
        messagebox.showinfo("Updated","Username/Password has been updated")
        data.close()

    def add_entry(self):
        data_1 = database()
        data_1.user_entry(self.usetxt.get(),self.pwtxt.get())
        messagebox.showinfo("Added", "Username&Password has been Add in user list")
        data_1.close()













if __name__ == '__main__':
    update()

