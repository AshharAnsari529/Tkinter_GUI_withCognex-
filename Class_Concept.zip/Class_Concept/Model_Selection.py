from tkinter import *
from tkinter import ttk
from MainScreen import main
from Camera_Program import Cam_network
from update_screen import *
from Setting_Screen import Settings




class model():
    def __init__(self,user_status):
        self.user_status = user_status
        self.model = Tk()
        self.model.resizable(width = False, height = False)
        self.width = self.model.winfo_screenwidth()
        self.height = self.model.winfo_screenheight()
        self.model.config(bg = "midnightblue")
        self.model.title("Model Selection")
        self.model.geometry(
            "%dx%d+%d+%d" % (self.width / 2 - 100, self.height / 2 - 100, self.width / 2 - (self.width / 2) / 2,
                             (self.height / 2 - (self.height / 2) / 2)))

        title_label = Label(self.model, text="Model Selection", bg="midnightblue", fg="White",
                            font=("Times", "24", "bold italic"))
        title_label.place(x=0, y=0,width = (self.width / 2 - 100))
        select_job_label = Label(self.model, text="Select Job", font=("Times", "18", "bold italic"),bg = "midnightblue",fg = "white")
        select_job_label.place(x=100, y=80)
        self.job_id = StringVar()
        job = ttk.Combobox(self.model, width=20, text=self.job_id, font=("Times", "18", "bold italic"))
        job.place(x=220, y=80)
        job["values"] = (
            "9441400M", "9441401M", "11311542XM", "11311544XM",
            "1184978XM", "1184979XM", "1203458XM", "1203459XM",
            "1352464XM", "1352465XM", "1338939XM", "13338940XM",
            "1222086XM", "1222087XM", "1431088XM", "1431090XM",
            "1285246XM", "1285247XM")
        BtnMain = Button(self.model, text="Main", font=("Times", "18", "bold italic"),command = self.close)
        BtnMain.place(x=250, y=180, width=120, height=50)
        self.BtnuserSettings = Button(self.model,text= "UserSetting",font=("Times", "18", "bold italic"),
                                      command = self.setting_page)

        self.BtnSettings = Button(self.model,text= "Settigs",font=("Times", "18", "bold italic"),
                                  command =lambda: self.config_settings_page())
        self.BtnSettings.place(x=370, y=180, width=120, height=50)
        self.BtnuserSettings.place(x=130, y=180, width=120, height=50)
        self.admin_user()


        self.model.mainloop()

    def close(self):

        if(self.job_change()):
            self.model.destroy()
            from database import database
            database_1 = database()
            database_1.update_runtimemodel(self.job_id.get())
            database_1.close()

            d = main()
    #
    def admin_user(self):


        if self.user_status:
           self.BtnuserSettings['state'] = "normal"
           self.BtnSettings['state'] = "normal"
        else:
            self.BtnuserSettings['state'] = "disabled"
            self.BtnSettings['state'] = "disabled"




    def setting_page(self):
        d = update()


    def config_settings_page(self):
        s = Settings()

    def job_change(self):
        job_1 = ["9441400M", "9441401M", "11311542XM", "11311544XM"]
        job_2 = ["1184978XM", "1184979XM", "1203458XM", "1203459XM"]
        job_3 = ["1352464XM", "1352465XM", "1338939XM", "13338940XM"]
        job_4 = ["1222086XM", "1222087XM", "1431088XM", "1431090XM"]
        job_5 = ["1285246XM", "1285247XM"]
        if len(self.job_id.get())>0:
            Cam_1 = Cam_network()
            Cam = Cam_1.connect()
            if(type(Cam) == str):
                messagebox.showerror("Connection Error","Camera Not Connected")
                return False
            else:
                if(self.job_id.get() in job_1):
                    status = Cam_1.job_change(1)
                    Cam_1.resetcount()
                    Cam_1.set_zero()
                    if status == "File Not Found":
                        messagebox.showerror("Not Found","File Not Found")
                        return False
                    else:

                        return  True

                elif(self.job_id.get() in job_2):
                    status = Cam_1.job_change(2)
                    Cam_1.resetcount()
                    Cam_1.set_zero()
                    if status == "File Not Found":
                        messagebox.showerror("Not Found","File Not Found")
                        return False
                    else:

                        return  True
                elif(self.job_id.get() in job_3):
                    status = Cam_1.job_change(3)
                    Cam_1.resetcount()
                    Cam_1.set_zero()
                    if status == "File Not Found":
                        messagebox.showerror("Not Found","File Not Found")
                        return False
                    else:

                        return  True

                elif(self.job_id.get() in job_4):
                    status = Cam_1.job_change(4)
                    Cam_1.resetcount()
                    Cam_1.set_zero()
                    if status == "File Not Found":
                        messagebox.showerror("Not Found","File Not Found")
                        return False
                    else:

                        return  True
                elif(self.job_id.get() in job_5):
                    status = Cam_1.job_change(5)
                    Cam_1.resetcount()
                    Cam_1.set_zero()
                    if status == "File Not Found":
                        messagebox.showerror("Not Found","File Not Found")
                        return False
                    else:

                        return  True




        else:
            messagebox.showerror("Select Job","please select one model")
            return False
        Cam_1.close_connection()

















if __name__ == '__main__':
    model()