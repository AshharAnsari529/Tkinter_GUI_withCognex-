from svglib.svglib import svg2rlg
from reportlab.graphics import renderPDF, renderPM
from PIL import Image
from PIL import ImageTk

from database import database


d = database()
image_path = d.show_config()
image_path = image_path[0][1]
d.close()

def svg_png(svg_file):
    try:
        drawing = svg2rlg(svg_file)
        d = renderPM.drawToFile(drawing, "temp.png", fmt="PNG")

    except:
        return "Image Not Found"

def rotate_image(rotate):

    try:

        d = svg_png(image_path)
        img = Image.open('temp.png').resize([800, 600], Image.BILINEAR)
        img = img.rotate(int(rotate))
        pimg = ImageTk.PhotoImage(img)
        return  pimg
    except:
        return "image not found"






