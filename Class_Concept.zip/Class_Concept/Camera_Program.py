import telnetlib
import re
from database import database



class Cam_network():
    def __init__(self):
        data = database()
        self.ip_port = data.show_config()
        self.result = self.ip_port[0][5]
        self.counter = self.ip_port[0][7]
        self.resetcounter = self.ip_port[0][8]

        data.close()

    def connect(self):
        try:
            self.tn = self.ip_port[0][2]
            user = b"admin\r\n"
            password = b"\r\n"
            self.tn = telnetlib.Telnet(self.tn, timeout=1000)
            self.tn.read_until(b"User: ",timeout=0.05)
            self.tn.write(user)
            self.tn.read_until(b":",timeout=0.05)
            self.tn.write(password)
            self.tn.read_until(b" In",timeout=0.05)

            return self.tn
        except:
            return "Cam Not Conneceted"

    def job_change(self, jobnumber):
        try:
            cam_offline = b"SO0\r\n"
            self.tn.write(cam_offline)
            self.tn.read_until(b"1",timeout=0.05)
            job = ("LF" + str(jobnumber) + "\r\n").encode('ascii')
            self.tn.write(job)
            self.tn.read_until(b"1",timeout=0.05)
            cam_online = b"SO1\r\n"
            self.tn.write(cam_online)
            self.tn.read_until(b"1",timeout=0.05)

        except Exception as e:
            return "File Not Found"

    def getvalue(self):
        try:

            result_cell = ("GV{}\r\n".format(self.result)).encode("ascii")
            self.tn.write(result_cell)
            self.tn.read_until(b"1",timeout=0.05)
            data = self.tn.read_until(b":",timeout=0.05)
            data = data.decode("ascii")
            data = data[:-1].strip()
            return data
        except:
            return  "Results Not Found"
    def getcount(self):
        try:
            counter_cell = ("GV{}\r\n".format(self.counter)).encode("ascii")
            self.tn.write(counter_cell)
            e = self.tn.read_until(b"1",timeout= 0.1)
            data = self.tn.read_until(b":",timeout=0.1)
            data = data.decode("ascii")
            count = data[:-1].strip()
            return count
        except:
            return  "Results Not Found"
    def resetcount(self):
        try:
            resetcounter_cell = ("SI{}1\r\n".format(self.resetcounter)).encode("ascii")
            self.tn.write(resetcounter_cell)
            e = self.tn.read_until(b"1",timeout= 0.1)
            resetcounter_cell_zero = ("SI{}0\r\n".format(self.resetcounter)).encode("ascii")
            self.tn.write(resetcounter_cell_zero)
            self.tn.read_until(b"1", timeout=0.1)

        except:
            return  "Results Not Found"
    def set_zero(self):
        try:
            resetcounter_cell_zero = ("SI{}0\r\n".format(self.resetcounter)).encode("ascii")
            self.tn.write(resetcounter_cell_zero)
            self.tn.read_until(b"1", timeout=0.1)
        except:
            return "Cell Not Found"


    def close_connection(self):
        self.tn.close()



if __name__ == '__main__':
    d = Cam_network()
    d.connect()
    # d.job_change(1)
    # s = d.getvalue()
    d.resetcount()
    d.set_zero()

