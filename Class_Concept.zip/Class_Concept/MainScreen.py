from tkinter import *
from datetime import datetime
from tkinter import messagebox
from csv import writer
from SVG_Image import rotate_image
from database import database
from PIL import Image,ImageTk
from os import path
from Camera_Program import Cam_network


class main():
    def __init__(self):
        self.mainscreen = Tk()
        self.mainheight = self.mainscreen.winfo_screenheight()
        self.mainwidth = self.mainscreen.winfo_screenwidth()
        self.mainscreen.geometry("%dx%d"%(self.mainwidth,self.mainheight))
        self.mainscreen.config(bg = "midnightblue")
        self.mainscreen.title("RM09 Vision Inspection")
        self.user = Label(self.mainscreen, text="   RM09 Vision Inspection", font=("Times", "24", "bold italic"), bg="midnightblue", fg="white",width = int(self.mainwidth/2))
        self.user.pack()
        self.time_label = Label(self.mainscreen, text = "AAAAA", font=("Times", "24", "bold italic"), bg="midnightblue", fg="white")
        self.time_label.place(x = self.mainwidth-150, y = 0)
        self.start_time = datetime.now()
        self.start_time = self.start_time.strftime("%H:%M:%S")




        self.current_variable = StringVar()
        self.current_user_label = Label(self.mainscreen, textvariable=self.current_variable, font=("Times", "24", "bold italic"),
                                        bg="midnightblue",fg = "White")
        self.current_user_label.place(x=self.mainwidth - 220, y=self.mainheight - 710, width=self.mainwidth - 1190)
        self.current_model_variable = StringVar()
        self.Model_Label = Label(self.mainscreen, text="Refrence", font=("Times", "24", "bold italic"),
                                 bg="midnightblue",fg = "White")
        self.Model_Label.place(x=self.mainwidth - 350, y=self.mainheight - 650)
        self.Countlbl = Label(self.mainscreen, text="Count", font=("Times", "24", "bold italic"),
                                 bg="midnightblue",fg = "White")
        self.Countlbl.place(x=self.mainwidth - 350, y=self.mainheight - 590)

        self.user_Label_sw = Label(self.mainscreen, text="User", font=("Times", "24", "bold italic"),
                                 bg="midnightblue",fg = "White")
        self.user_Label_sw.place(x=self.mainwidth - 350, y=self.mainheight - 710)




        self.Model = Label(self.mainscreen, textvariable=self.current_model_variable, font=("Times", "24", "bold italic"),
                           bg="midnightblue",fg = "White")
        self.Model.place(x=self.mainwidth - 220, y=self.mainheight - 650, width=self.mainwidth - 1190)
        self.count_variable = StringVar()
        self.count = Label(self.mainscreen, text=self.count_variable, font=("Times", "24", "bold italic"),
                           bg="midnightblue",fg = "White")
        self.count.place(x=self.mainwidth - 220, y=self.mainheight - 590, width=self.mainwidth - 1190)
        self.current_model()
        self.current_user()
        self.image = rotate_image(self.degree)

        self.image_label = Label(self.mainscreen, image=self.image)
        self.image_label.place(x=self.mainwidth - 1316, y=self.mainheight - 718)

        self.result_lbl = Label(self.mainscreen,font=("Times", "140", "bold italic"),text = "ABC",bg = "midnightblue",fg = "White")
        self.result_lbl.place(x=self.mainwidth - 450, y=self.mainheight - 490,width = 400,height = 370)


        # self.image_label1 = Label(self.mainscreen)
        #
        # r
        # # Position image
        # self.image_label1.place(x=self.mainwidth - 400, y=self.mainheight - 430)
        # self.result()

        # self.getresult()
        self.camcount()
        self.time()
        self.image_show()
        self.getresult()
        self.mainscreen.protocol("WM_DELETE_WINDOW", self.save)
        self.mainscreen.mainloop()

    def time(self):
        self.now = datetime.now()
        self.current_time = self.now.strftime("%H:%M:%S")
        self.time_label.config(text=self.current_time)
        self.mainscreen.after(1000, self.time)

    def save(self):
            if messagebox.askokcancel("Quit", "Do you want to quit?"):
                self.stop_time = datetime.now()
                self.stop_time = self.stop_time.strftime("%H:%M:%S")
                date = datetime.now()
                date = str(date.date())
                model_number =  self.current_model_variable.get()
                user = self.current_variable.get()
                report_path = r"{}\{}.csv".format(self.report_path,date)
                count = self.count_value

                data = [self.start_time,model_number,user,self.stop_time,count]
                heading = ["Start Time","Model Number","User","Stop Time","Total_Parts"]
                if(not path.exists(report_path)):
                    f = open(report_path,"a",newline="")
                    writer_object = writer(f)
                    writer_object.writerow(heading)
                    f.close()
                with open(report_path,"a+",newline='') as f:
                    writer_object = writer(f)
                    writer_object.writerow(data)
                cam2 = Cam_network()
                cam2.connect()
                cam2.resetcount()
                cam2.set_zero()
                self.mainscreen.destroy()



    def image_show(self):
        self.image = rotate_image(self.degree)
        self.image_label.config(image=self.image)
        self.mainscreen.after(500,self.image_show)

    def current_user(self):
        database_1 = database()
        runtime=database_1.show_runtimeuser()
        self.current_variable.set(runtime)
        database_1.connection.close()
    def current_model(self):
        database_1 = database()
        runtime=database_1.show_runtimemodel()
        self.current_model_variable.set(runtime)
        self.degree = database_1.show_rotate()
        self.report_path = database_1.show_config()
        self.report_path = self.report_path[0][4]
        database_1.connection.close()

    def camcount(self):
        self.cam1 = Cam_network()
        self.cam1.connect()

        self.count_value = self.cam1.getcount()
        self.count.config(text  =self.count_value)
        self.mainscreen.after(200,self.camcount)

    def getresult(self):
        self.cam2 = Cam_network()
        self.cam2.connect()
        result = self.cam2.getvalue()
        if result == "OK":
            self.result_lbl.config(fg = "lawn green",text = "OK")

        else:
            self.result_lbl.config(fg = "sienna1",text = "NG")
        self.mainscreen.after(200,self.getresult)

























if __name__ == '__main__':
    main()