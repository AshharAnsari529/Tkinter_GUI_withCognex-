from tkinter import *
from database import database
from tkinter import messagebox

class Settings():
    def __init__(self):
        self.setting = Tk()
        self.setting.title("Settings")
        self.setting.resizable(width=False, height=False)
        self.setting_width = self.setting.winfo_screenwidth()
        self.setting_height = self.setting.winfo_screenheight()
        self.setting.config(bg="midnightblue")
        self.setting.title("Parameter Settings")
        self.setting.geometry(
            "%dx%d+%d+%d" % (self.setting_width / 2, self.setting_height / 2+200, self.setting_width / 2 - (self.setting_width / 2) / 2,
                             (self.setting_height / 2 - (self.setting_height / 2+300) / 2)))
        title = Label(self.setting, text="Parameter Settings", bg="midnightblue", fg="White",
                           font=("Times", "24", "bold italic"))
        title.place(x=0, y=0, width=(self.setting_width / 2))
        label_1 = Label(self.setting,text = "Image Path",font=("Times", "15", "bold italic"),bg = "midnightblue", fg = "white" )
        label_1.place(x = 110 , y = 50)
        label_2 = Label(self.setting,text = "Report Path",font=("Times", "15", "bold italic"),bg = "midnightblue", fg = "white" )
        label_2.place(x = 450 , y = 50)
        label_3 = Label(self.setting,text = "Camera Port",font=("Times", "15", "bold italic"),bg = "midnightblue", fg = "white" )
        label_3.place(x = 450 , y = 150)
        label_4 = Label(self.setting,text = "Camera IP",font=("Times", "15", "bold italic"),bg = "midnightblue", fg = "white" )
        label_4.place(x = 110 , y = 150)
        label_5 = Label(self.setting,text = "Rotate",font=("Times", "15", "bold italic"),bg = "midnightblue", fg = "white" )
        label_5.place(x = 120 , y = 250)
        label_6 = Label(self.setting,text = "Results Cell",font=("Times", "15", "bold italic"),bg = "midnightblue", fg = "white" )
        label_6.place(x = 450 , y = 250)
        label_7 = Label(self.setting,text = "Counter Cell",font=("Times", "15", "bold italic"),bg = "midnightblue", fg = "white" )
        label_7.place(x = 450 , y = 350)
        label_8 = Label(self.setting,text = "Reset CounterCell",font=("Times", "15", "bold italic"),bg = "midnightblue", fg = "white" )
        label_8.place(x = 110 , y = 350)
        self.image_path_txt_variable = StringVar()
        self.image_path_txt = Entry(self.setting, font=("Times", "12"),textvariable = self.image_path_txt_variable,
                                   justify=CENTER)
        self.image_path_txt.place(width=300, height=40,x=20, y=90)
        self.report_path_txt_variable = StringVar()
        self.report_path_txt = Entry(self.setting, font=("Times", "12"),textvariable = self.report_path_txt_variable,
                                    justify=CENTER)
        self.report_path_txt.place(width=300, height=40,x=350, y=90)
        self.camera_ip_txt_variable = StringVar()
        self.camera_ip_txt =Entry(self.setting, font=("Times", "12"),textvariable = self.camera_ip_txt_variable,
                                  justify=CENTER)
        self.camera_ip_txt.place(width=300, height=40,x=20, y=190)

        self.camera_port_txt_variable = StringVar()
        self.camera_port_txt =Entry(self.setting, font=("Times", "12"),textvariable = self.camera_port_txt_variable,
                                    justify=CENTER)
        self.camera_port_txt.place(width=300, height=40,x=350, y=190)

        self.rotate_txt_variable = StringVar()
        self.rotate_txt =Entry(self.setting, font=("Times", "12"),textvariable = self.rotate_txt_variable,
                               justify=CENTER)
        self.rotate_txt.place(width=300, height=40,x=20, y=280)

        self.result_txt_variable = StringVar()
        self.result_txt =Entry(self.setting, font=("Times", "12"),textvariable = self.result_txt_variable,
                               justify=CENTER)
        self.result_txt.place(width=300, height=40,x=350, y=280)

        self.counter_txt_variable = StringVar()
        self.counter_txt =Entry(self.setting, font=("Times", "12"),textvariable = self.counter_txt_variable,
                               justify=CENTER)
        self.counter_txt.place(width=300, height=40,x=350, y=380)

        self.resetcounter_txt_variable = StringVar()
        self.resetcounter_txt =Entry(self.setting, font=("Times", "12"),textvariable = self.resetcounter_txt_variable,
                               justify=CENTER)
        self.resetcounter_txt.place(width=300, height=40,x=20, y=380)


        self.update_config_btn = Button(self.setting, font=("Times", "15", "bold italic"), text="Update",
                                      command = self.update_config)
        self.update_config_btn.place(x=530, y=530, width=120, height=40)

        self.txt_entry()
        self.setting.mainloop()


    def txt_entry(self):
        data = database()
        value = data.show_config()
        try:
            self.image_path_txt.insert(0,value[0][1])
            self.camera_ip_txt.insert(0,value[0][2])
            self.camera_port_txt.insert(0,value[0][3])
            self.report_path_txt.insert(0, value[0][4])
            self.result_txt.insert(0,value[0][5])
            self.rotate_txt.insert(0, value[0][6])
            self.counter_txt.insert(0,value[0][7])
            self.resetcounter_txt.insert(0,value[0][8])
        except:
            pass





    def update_config(self):
        data_1 = database()
        data_1.update_config(self.image_path_txt.get(),self.report_path_txt.get(),
                             self.camera_ip_txt.get(),self.camera_port_txt.get(),self.result_txt.get(),
                             int(self.rotate_txt.get().strip()),self.counter_txt.get().strip(),self.resetcounter_txt.get())

        messagebox.showinfo("Updated","Data has been updated")
        value = data_1.show_config()

        try:
            self.image_path_txt.delete(0,END)
            self.image_path_txt.insert(0,value[0][1])
            self.camera_ip_txt.delete(0, END)
            self.camera_ip_txt.insert(0,value[0][2])
            self.camera_port_txt.delete(0, END)
            self.camera_port_txt.insert(0,value[0][3])
            self.report_path_txt.delete(0, END)
            self.report_path_txt.insert(0, value[0][4])
            self.result_txt.delete(0, END)
            self.result_txt.insert(0,value[0][5])
            self.rotate_txt.delete(0, END)
            self.rotate_txt.insert(0, value[0][6])
            self.counter_txt.delete(0,END)
            self.counter_txt.insert(0, value[0][7])
            self.resetcounter_txt.delete(0,END)
            self.resetcounter_txt.insert(0, value[0][8])
        except:
            pass
        finally:
            data_1.close()












if __name__ == '__main__':
    Settings()