import sqlite3


class database():
    def __init__(self):
        self.connection = sqlite3.connect("RM09.db")
        self.cursor= self.connection.cursor()
        self.user_table = """CREATE TABLE IF NOT EXISTS USER(ID INTEGER PRIMARY KEY AUTOINCREMENT , USERNAME TEXT NOT NULL , PASSWORD TEXT NOT NULL)"""
        self.config = """CREATE TABLE IF NOT EXISTS CONFIG(ID INTEGER PRIMARY KEY AUTOINCREMENT , IMAGEPATH TEXT , CAMERAIP TEXT , CAMERAPORT TEXT
        ,REPORTPATH TEXT,RESULTCELL TEXT,ROTATE INTEGER)"""
        self.userruntime = """CREATE TABLE IF NOT EXISTS USERRUNTIME(ID INTEGER PRIMARY KEY AUTOINCREMENT , USER TEXT)"""
        self.modelruntime = """CREATE TABLE IF NOT EXISTS MODELRUNTIME(ID INTEGER PRIMARY KEY AUTOINCREMENT , MODEL TEXT)"""
        self.cursor.execute(self.userruntime)
        self.cursor.execute(self.modelruntime)
        self.connection.commit()
    def execute(self,data):
        self.cursor.execute(data)
    def commit(self):
        self.connection.commit()
    def user_entry(self,username,password):
        self.cursor.execute("insert into USER (USERNAME, PASSWORD) values(?,?)",(username.upper(), password.upper()))
        self.commit()
    def update_config(self,image_path,report_path,camera_ip,camera_port,result_cell,rotate,counter,resetcounter):
        self.cursor.execute("update config set IMAGEPATH = ? , CAMERAIP = ? , CAMERAPORT = ? , REPORTPATH = ?,"
                            "RESULTCELL = ? , ROTATE = ?,COUNTER = ?,RESETCOUNTER=?",
                            (image_path,camera_ip,camera_port,report_path,result_cell,rotate,counter,resetcounter))
        self.commit()
    def show_user(self):
        d = self.cursor.execute("select USERNAME from USER")
        data = d.fetchall()
        data_1 = []
        for i in range(len(data)):
            data_1.append(data[i][0])
        return data_1


    def show_pw(self):
        d = self.cursor.execute("select PASSWORD from USER")
        data = d.fetchall()
        data_1 = []
        for i in range(len(data)):
            data_1.append(data[i][0])
        return data_1
    def update_runtimeuser(self,runtime_user):
        self.cursor.execute("UPDATE USERRUNTIME SET USER = ? where id =1",(runtime_user.upper(),))
        self.connection.commit()
    def update_runtimemodel(self,runtime_model):
        self.cursor.execute("UPDATE MODELRUNTIME SET MODEL = ?",(runtime_model,))
        self.connection.commit()

    def show_runtimeuser(self):
        runtime = self.cursor.execute("select * from userruntime")
        self.commit()
        runtime = runtime.fetchall()[0][1]
        return runtime
    def show_runtimemodel(self):
        model = self.cursor.execute("select * from modelruntime")
        self.commit()
        model = model.fetchall()[0][1]
        return model
    def show_rotate(self):
        angle = self.cursor.execute("select ROTATE from config")
        angle = angle.fetchall()
        angle = angle[0][0]
        return int(angle)
    def show_user_pw(self,user):
        user_pw = self.cursor.execute("Select * from USER where USERNAME = ?",(user,))
        user_pw = user_pw.fetchall()
        return user_pw
    def update_user(self,cur,update_username,update_password):
        self.cursor.execute("""UPDATE USER SET PASSWORD = ?,USERNAME = ? WHERE USERNAME = ?"""
                            ,(update_password.upper(),update_username.upper(),cur.upper()))
        self.connection.commit()
    def show_config(self):
        self.cursor.execute("select * from config")
        config_file = self.cursor.fetchall()
        return config_file
    def verify_pw(self,cur_userame):
        self.cursor.execute("Select PASSWORD FROM USER where USERNAME = ?",(cur_userame.upper(),))
        data = self.cursor.fetchall()
        return data[0][0]
    def close(self):
        self.connection.close()




if __name__ == '__main__':

    d = database()

    x = d.verify_pw("A")

    print(x)


