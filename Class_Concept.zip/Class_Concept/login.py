from tkinter import *
from Model_Selection import model
from database import database
from tkinter import messagebox
import os


def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)
class GUI():
    def __init__(self):
        # <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Initialise Main Window>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        self.Mainwindow = Tk()
        self.height = self.Mainwindow.winfo_screenheight()
        self.width = self.Mainwindow.winfo_screenwidth()
        self.Mainwindow.config(bg="midnightblue")
        # print(self.height,self.width)
        self.Mainwindow.geometry(
            "%dx%d+%d+%d" % (self.width / 2 - 100, self.height / 2 - 100, self.width / 2 - (self.width / 2) / 2,
                             (self.height / 2 - (self.height / 2) / 2)))
        # <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Initialise Window Widgets>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        self.heading = Label(self.Mainwindow, text="Login Screen", font=("Times", "24", "bold italic"),
                             bg="midnightblue", fg="white").place(x=0, y=0, width=(self.width / 2 - 100))
        self.user_entry_variable = StringVar()
        self.pw_entry_variable = StringVar()
        self.label = Label(self.Mainwindow, text="Username", font=("Times", "18", "bold italic"), bg="midnightblue"
                           , fg="white").place(x=80, y=80)
        self.user_entry = Entry(self.Mainwindow,textvariable= self.user_entry_variable, font=("Times", "18")).place(width=200, height=40,
                                                                             x=self.width / 6, y=80)
        self.label = Label(self.Mainwindow, text="Password", font=("Times", "18", "bold italic"), bg="midnightblue",
                           fg="white").place(x=80, y=130)
        self.pw_entry = Entry(self.Mainwindow,textvariable=self.pw_entry_variable, font=("Times", "18")).place(width=200, height=40,
                                                                           x=self.width / 6, y=130)

        self.exit = Button(self.Mainwindow, text="Exit", font=("Times", "18", "bold italic"), bg="red", fg="white",
                           command=self.close).place(width=80, x=self.width / 2.9, y=220, height=40)

        # self.page2 = Button(self.Mainwindow, text="Page1",command = self.Login ).place(x=0, y=10)
        self.login = Button(self.Mainwindow, text="Login", font=("Times", "18", "bold italic"),command = self.login
                            ).place(width=80, x=self.width / 6, y=200, height=40)

        self.Mainwindow.mainloop()

    def close(self):
        self.Mainwindow.destroy()

    def login(self):

        self.d = database()
        self.user = self.d.show_user()
        self.pw = self.d.show_pw()
        # user_pw = self.d.show_user_pw()



        if(self.user_entry_variable.get().upper() in self.user and self.pw_entry_variable.get().upper() in self.pw and
                self.d.verify_pw(self.user_entry_variable.get().upper()) == self.pw_entry_variable.get().upper()):

            self.close()
            j = self.user_entry_variable.get().upper().strip() == "ADMIN"
            m = model(j)


            self.d.update_runtimeuser(self.user_entry_variable.get())







        else:
            messagebox.showinfo("UserName/Password","Please enter correct username/password")
        self.d.connection.close()







GUI()
resource_path(r"C:\Users\Lenovo\Downloads\solution_idea_creativity_innovation_bulb_icon_191141.ico")