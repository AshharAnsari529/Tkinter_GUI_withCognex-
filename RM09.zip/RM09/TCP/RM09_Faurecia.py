from tkinter import *
import pandas as pd
from tkinter import messagebox
import os
from tkinter import ttk
from JobChange import connectcam,job_change,getvalue
from svglib.svglib import svg2rlg
from reportlab.graphics import renderPDF, renderPM
from PIL import Image, ImageTk
from PIL import *
import time
from datetime import datetime
from csv import writer


def set_dll_search_path():
   # Python 3.8 no longer searches for DLLs in PATH, so we have to add
   # everything in PATH manually. Note that unlike PATH add_dll_directory
   # has no defined order, so if there are two cairo DLLs in PATH we
   # might get a random one.
   if os.name != "nt" or not hasattr(os, "add_dll_directory"):
       return
   for p in os.environ.get("PATH", "").split(os.pathsep):
       try:
           os.add_dll_directory(p)
       except OSError:
           pass

def get_svg(svg_file):
    try:
        drawing = svg2rlg(svg_file)
        d = renderPM.drawToFile(drawing, "temp.png", fmt="PNG")
    except:
        pass


# print(os.getcwd())
path = str(os.getcwd())+r"\COnfig_FIle\Username.csv"
date = datetime.now()
date = str(date.date())
# print(date)
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<DATA FROM CSV>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
file = pd.read_csv(path)
user = list(file["UName"])
image_path = list(file["Image_Path"])
image_path = str(image_path[0])
image_path = r"{}".format(image_path)



Report_Path = list(file["Report Path"])
Report_Path = Report_Path[0]
Report_Path = str(Report_Path)
Report_Path = r"{}\{}.csv".format(Report_Path,date)
# print(image_path)
pw = list(file["Password"])
ip = list(file["IP"])

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<GUI FUNCTION>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
def Login():

    def Setting_GUI(main=None):
        Setting = Tk()

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Main>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        def MainPage():
            Main = Tk("Main")
            with open("user.txt", "r") as f:
                user = f.read()

                userlabel = StringVar()
                userlabel.set(str(user))


                f.close()
            with open("Imp.txt","r") as f:
                Model_no_text = StringVar()

                Model_no_text.set(str(f.read()))
                model = f.read()

                f.close()


            screen_width = Main.winfo_screenwidth()
            screen_height = Main.winfo_screenheight()
            Main.geometry((str(screen_width) + "x" + str(screen_height)))
            # print(screen_height, screen_width)
            user = Label(Main, text="RM09 Camera Inspection", font=('Helvetica', 18, 'bold'), bg="Blue", fg="white")
            user.place(x=screen_width - screen_width, y=screen_height - screen_height, width=screen_width-120)
            time_label = Label(Main, text="Faurecia", font=('Helvetica', 18, 'bold'), bg="Blue", fg="white")
            time_label.place(x=screen_width - 200, y=screen_height - screen_height, width=screen_width-1190)
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Time Loop>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            def time():
                now = datetime.now()

                current_time = now.strftime("%H:%M:%S")
                time_label.config(text = current_time)
                Main.after(200,time)
            time()

            img_label = Label(Main, text="User", font=('Helvetica', 18, 'bold'))
            img_label.place(x=screen_width - 300, y=screen_height - 710)
            user_label = Label(Main, textvariable= userlabel, font=('Helvetica', 18, 'bold'), bg = "seashell3")
            user_label.place(x=screen_width - 220, y=screen_height - 710, width = screen_width-1190)
            Model_Label = Label(Main, text="Refrence", font=('Helvetica', 18, 'bold'))
            Model_Label.place(x=screen_width - 350, y=screen_height - 650)
            Model_no_label = Label(Main, textvariable= Model_no_text, font=('Helvetica', 18, 'bold'), bg = "seashell3")
            Model_no_label.place(x=screen_width - 220, y=screen_height - 650, width = screen_width-1190)
            global img_1,ng_img,frame_1
            try:
                img_1 = Image.open(str(os.getcwd()) + r"\COnfig_FIle\NG.png")
                ng_img = ImageTk.PhotoImage(img_1)
                OK_Label = Label(Main,text = "NG",font=('Helvetica', 180, 'bold'))
                OK_Label.place(x=screen_width - 400, y=screen_height - 550, width=screen_width - 1000,height = screen_height-400)

            except:
                pass

            def pick():

                try:
                    cam = connectcam()
                    d = getvalue(cam)

                    if d == "OK":

                        # img_2 = Image.open(str(os.getcwd()) + r"\COnfig_FIle\OK.png")
                        # img = ImageTk.PhotoImage(img_2)
                        OK_Label.config(text = "OK")
                        OK_Label.config(bg = "Green")
                        OK_Label.config(fg = "White")
                        # OK_Label.config(image = img)

                    else:
                        # img_3 = Image.open(str(os.getcwd()) + r"\COnfig_FIle\NG.png")
                        # img1 = ImageTk.PhotoImage(img_3)
                        OK_Label.config(text = "NG")
                        OK_Label.config(bg = "Red")
                        OK_Label.config(fg = "White")
                        # OK_Label.config(image = img1)






                except:
                    pass
                finally:

                    Main.after(500, pick)




            pick()




            # try:
            #
            #     get_svg(image_path)
            #     img = Image.open('temp.png')
            #     pimg = ImageTk.PhotoImage(img)
            #     size = img.size
            #
            #     frame = Canvas(Main, width=(size[0]), height=(size[1]))
            #     frame.place(x=screen_width - 1316, y=screen_height - 718)
            #
            # except:
            #     messagebox.showinfo("Image Not Found")

            try:
                get_svg(image_path)
                img = Image.open('temp.png').resize([800,600],Image.BILINEAR)
                img = img.rotate(180)
                pimg = ImageTk.PhotoImage(img)

            except:
                pass
            image_label = Label(Main, image=pimg)
            image_label.place(x=screen_width - 1316, y=screen_height - 718)

            def update():
                global pimg1
                try:
                    get_svg(image_path)
                    img4 = Image.open('temp.png').resize([800,600],Image.BILINEAR)
                    img4 = img4.rotate(180)
                    pimg1 = ImageTk.PhotoImage(img4)
                    image_label.config(image = pimg1)



                except:
                    pass
                finally:
                    Main.after(500,update)

            update()




























            def save():
                if messagebox.askokcancel("Quit", "Do you want to quit?"):

                    with open(Report_Path,"a") as f:


                        now = datetime.now()

                        current_time = now.strftime("%H:%M:%S")
                        data = [userlabel.get(),Model_no_text.get(),date,current_time]
                        writer_object = writer(f)
                        writer_object.writerow(data)
                        f.close()
                    Main.destroy()
            Main.protocol("WM_DELETE_WINDOW",save)


            Main.mainloop()
            return Main
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Close And Open Main<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        def close():
            Setting.destroy()
            MainPage()


#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Setting Page Widgets>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        Setting.title("Model Selection")
        Setting.geometry("500x250+400+200")
        Setting.resizable(width=False, height=False)

        title_label = Label(Setting, text="Model Selection", bg="Blue", fg="White", height="2", width="40",
                            font=('Helvetica', 14, 'bold'))
        title_label.place(x=0, y=0)
        select_job_label = Label(Setting, text="Select Job", font=('Helvetica', 10, 'bold'))
        select_job_label.place(x=100, y=80)
        job_id = StringVar()
        job = ttk.Combobox(Setting, width=20, text=job_id,font=('Helvetica', 10, 'bold'))
        job.place(x=200, y=80)
        job["values"] = (
        "9441400M", "9441401M", "11311542XM", "11311544XM",
        "1184978XM", "1184979XM", "1203458XM","1203459XM",
        "1352464XM", "1352465XM", "1338939XM", "13338940XM",
        "1222086XM", "1222087XM", "1431088XM", "1431090XM",
        "1285246XM", "1285247XM")


     #close function and model selection
        def close():
            with open("Imp.txt","w") as f:
                f.write(job_id.get())
            job_1 = ["9441400M", "9441401M", "11311542XM", "11311544XM"]
            job_2 = ["1184978XM", "1184979XM", "1203458XM", "1203459XM"]
            job_3 = ["1352464XM","1352465XM", "1338939XM", "13338940XM"]
            job_4 = ["1222086XM", "1222087XM", "1431088XM", "1431090XM"]
            job_5 = ["1285246XM", "1285247XM"]
            try:

                cam = connectcam()
            except:
                messagebox.showerror("Camera Didn't connect", "Communication Error")


            if job_id.get() in job["values"] and job_id.get() in job_1:
                job_change(cam,1)
                Setting.destroy()
                MainPage()
            elif (job_id.get() in job["values"] and job_id.get() in job_2):
                job_change(cam, 2)
                Setting.destroy()
                MainPage()
            elif (job_id.get() in job["values"] and job_id.get() in job_3):
                job_change(cam, 3)
                Setting.destroy()
                MainPage()
            elif (job_id.get() in job["values"] and job_id.get() in job_4):
                job_change(cam, 4)
                Setting.destroy()
                MainPage()
            elif (job_id.get() in job["values"] and job_id.get() in job_5):
                job_change(cam, 4)
                Setting.destroy()
                MainPage()

            else:
                messagebox.showinfo("Please Select One Model","Select Model")



        BtnMain = Button(Setting, text="Main", font=('Helvetica', 18, 'bold'),command = lambda: close())
        BtnMain.place(x=160, y=140, width=90, height=50)
        return Setting

    def login(username, pw):
        if (username in user and pw in pw):
            with open("user.txt", "w") as f:
                window.destroy()
                Setting_GUI()
                f.write(username)

            return True
        else:
            messagebox.showinfo("UserName", "Please enter username/pw")
            loginstuts = False
            return False

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Login Page>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    window = Tk("Login Page")
    window.geometry("500x250+400+200")
    window.title("Login Page")
    window.resizable(width= False , height = False)


    user_name = Label(window,text = "UserName",font=('Helvetica', 18, 'bold'))
    user_name.place(x = 60 , y = 33)

    password = Label(window, text = "Password",font=('Helvetica', 18, 'bold'))
    password.place(x = 60, y = 92)
    pw_variable = StringVar()
    user_variable = StringVar()

    user_name_entry = Entry(window,textvariable = user_variable,width = 20,font=('Helvetica', 18, 'bold'))
    user_name_entry.place(x = 190 , y = 40, height = 30)


    pw_name_entry = Entry(window,textvariable = pw_variable, show = "*",width = 20,font=('Helvetica', 18, 'bold'))
    pw_name_entry.place(x = 190 , y = 100, height = 30)

    BtnLogin = Button(window, text = "Login" ,bg = "Pink",font=('Helvetica', 18, 'bold'), command = lambda: login(user_variable.get(),pw_variable.get()))
    BtnLogin.place(x = 190, y = 160 , width = 90 , height = 50 )

    BtnQuit = Button(window, text="Exit",bg = "red" ,font=('Helvetica', 18, 'bold'),command=lambda:window.destroy())
    BtnQuit.place(x=420, y=180)

    window.mainloop()




set_dll_search_path()
Login()
