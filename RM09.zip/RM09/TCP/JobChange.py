import socket
import time
import telnetlib
import re
import pandas as pd
import os



def removetag(tag):
    return re.sub("<[^>]*>","",tag)



def connectcam():
    try:
        path = str(os.getcwd()) + r"\COnfig_FIle\Username.csv"
        file = pd.read_csv(path)
        ip = list(file["IP"])
        ip = ip[0]
        # print(ip)

        host = ip
        user = b"admin\r\n"
        password = b"\r\n"
        tn = telnetlib.Telnet(host)
        c = tn.read_until(b"User: ")
        tn.write(user)
        tn.read_until(b":")
        tn.write(password)
        tn.read_until(b" In")
        return tn
    except:
        pass



def job_change(host,jobnumber):
    try:
        cam_offline = b"SO0\r\n"
        host.write(cam_offline)
        host.read_until(b"1")
        job = ("LF"+str(jobnumber)+"\r\n").encode('ascii')
        host.write(job)
        host.read_until(b"1")
        cam_online = b"SO1\r\n"
        host.write(cam_online)
        host.read_until(b"1")
        host.close()
    except Exception as e:
        pass

def getvalue(host):
    try:

        get_value = b"GVN002\r\n"

        host.write(b"GVN002\r\n")

        host.read_until(b"1")

        data = host.read_until(b":")
        data = data.decode("ascii")

        data = data[:-1].strip()
    except:
        pass


    return data


# c= connectcam()
# d = getvalue(c)
# print(d)
# if d=="OK":
#     print("hey")


















